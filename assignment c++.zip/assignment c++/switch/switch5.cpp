//5. C++ Program To Generate Table Of Any Number Using Goto Statement. 
#include<iostream>
using namespace std;
int main()
{
	int a,b,i=1;
	cout<<"Enter the limit:-"<<" ";
	cin>>a;
	cout<<"Enter the table number:-"<<" ";
	cin>>b;
	start:
		cout<<"\n"<<b<<"*"<<i<<"="<<b*i;
		i++;
		if(i<=a){
			goto start;
		}
	
	
	
	
}

