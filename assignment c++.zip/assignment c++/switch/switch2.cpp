//2. C++ Program To Find  Cube/ Square / Even-Odd  Using Switch Statement 
#include<iostream>
using namespace std;
int main()
{
   int ch,a,b,i=0;
   

	

   cout<<"Enter your choice \n 1 for find the volume of cube \n 2 for find the surface area of cube \n 3 to find even or odd number \n";
    cin>>ch;
    
   cout<<"Enter the value:-"<<" ";
   cin>>a;
   
	switch(ch){
    	case 1:
    		cout<<"volume of cube is:-"<<(a*a*a)<<endl;
    		break;
    	case 2:
    		cout<<"surface area of cube is:"<<6*(a*a)<<endl;
    		break;
    	case 3:
    		
    		if(a%2==0){
    			cout<<a<<" "<<"number is even"<<endl;
			}
			else{
				cout<<a<<" "<<"number is odd"<<endl;
				
			}
    		
	}
	

} 
