//4. C++ Program To Find Swapping / Smallest Between Two / Area Of  Rectangle 
//Using Switch Statement 
#include<iostream>
using namespace std;
int main()
{
	int ch;
	cout<<"Enter your choice \n 1 for swapping \n 2 for smallest two \n 3 for area of rectangle \n";
	cin>>ch;
	switch(ch){
		case 1:
			int a,b,c;
			cout<<"Enter the value first:-"<<" ";
			cin>>a;
			cout<<"Enter the value second:-"<<" ";
			cin>>b;
			c=a;
			a=b;
			b=c;
			cout<<"After swapping of number"<<endl;
			cout<<"your first value is:- "<<" "<<a<<endl;
			cout<<"your second value is:- "<<" "<<b<<endl;
			break;
		case 2:
			int d,e,f;
			cout<<"Enter the value first:-"<<" ";
			cin>>d;
			cout<<"Enter the value second:-"<<" ";
			cin>>e;
			if(e>d){
				cout<<d<<" is smallest"<<endl;
			}
			else{
				cout<<e<<" is smallest"<<endl;
			}
			break;
		case 3:
			int l,w;
			cout<<"Enter the length of rectangle:- ";
			
			cin>>l;
			cout<<"Enter the width of rectangle:- ";
			cin>>w;
			
			cout<<"Area of rectangle is:- "<<l*w<<endl;
			
	
	   
			
	}
}