//3. C++ Program To Check Whether Character ,Digit Or A Special Symbol Using 
//Switch Case
#include<iostream>
using namespace std;
int main()
{
 char c;
 cout<<"Enter the character:- ";
 cin>>c;
 switch(c>='a'&& c<='z' || c>='A' && c<='z'){
 	case 1:
 		cout<<"It is an character"<<endl;
 		break;
 		case 0:
 			switch(c>='0' || c<='9'){
 				case 1:
 					
 				   cout<<"It is an number";
 				   break;
 				   case 0:
 				   	cout<<"It is a special character"<<endl;
 				
			 }
 }
}