//1. C++ Program To Perform Arithmetic Operations Using Switch Case
#include<iostream>
using namespace std;
int main()
{
   int ch,a,b,i=0;
while(i<4){
	

   cout<<"Enter the first value:-"<<" ";
   cin>>a;
   cout<<"Enter the second value:-"<<" ";
   cin>>b;
   cout<<"Enter your choice \n 1 for add \n 2 for substract \n 3 for multiply \n 4 for divide \n";
    cin>>ch;
   
	switch(ch){
    	case 1:
    		cout<<"add is:-"<<a+b<<endl;
    		break;
    	case 2:
    		cout<<"substract is:-"<<a-b<<endl;
    		break;
    	case 3:
    		cout<<"multiply is:-"<<a*b<<endl;
    		break;
    	case 4:
    		cout<<"Divide is:-"<<a/b<<endl;
    		break;
    	default:
    		cout<<"unknown value"<<endl;
    	    break;
    		
	}
	i++;
}
} 
