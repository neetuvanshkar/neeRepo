//12. C++ Program To Find Number Is Prime Or Not 
#include<iostream>
using namespace std;
int main()
{
	int a,c;
	cout<<"Enter the number:- ";
	cin>>a;
	for(int i=1; i<=a; i++){
		if(a%i==0){
			c++;
		}
	}
	if(c==2){
		cout<<a<<" is prime number"<<endl;
	}
	else{
		cout<<a<<" is not prime number"<<endl;
		
	}
}