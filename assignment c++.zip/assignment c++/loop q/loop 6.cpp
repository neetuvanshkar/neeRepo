//6. C++ Program To Print The Fibonacci Series Up To The Given Number Of 
//Terms 
#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"Enter the number:- ";
	cin>>a;
	int s=0;
	int t=1;
	int y;
	cout<<"The fibonacci series is:- \n";
	for(int i=1; i<=a; i++)
	{
		cout<<s<<endl;  // 0,1,1,2
		y=s+t;    // y=1,y=2,y=3
		s=t;      //s=1,s=1,s=2,
		t=y;      //t=1,t=2,t=3
		
		
		
	}
}