//4. C++ Program Convert Binary Number To Decimal Number Using Loop 
//10. C++ Program For Denomination Of An Amount Using While Loop 
#include<iostream>
using namespace std;
int main()
{
	int a,rem,w;
	cout<<"Enter the binary number:- ";

	cin>>a;
	int decimal=0; w=1;
	while(a!=0)
	{
		rem=a%10;
		decimal+=rem*w;
		a=a/10;
		w=w*2;
		
	}
    cout<<"the decimal equivalent of binary number "<<decimal;
    

	
}