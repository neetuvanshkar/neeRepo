//9. C++ Program To Find Whether A Number Is Palindrome Or Not
#include<iostream>
using namespace std;
int main()
{
	int val,rev=0,num;
	cout<<"Enter the number:- ";
	cin>>num;
	val=num;
	while(num>0){
		int rem=num%10;
		rev=rev*10+rem;   //0+1,1 ,2       
		num=num/10;      // 121/10,12
		
	}
	if(val==rev){
		cout<<val<<" is palidrome";
	}
	else{
		cout<<val   <<" is not palidrome";
	}

	
} 