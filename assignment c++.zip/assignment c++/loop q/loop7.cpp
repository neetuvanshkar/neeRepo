//7. C++ Program To Sort Elements In Lexicographical Order (Dictionary Order) 
//Using For Loop 

#include<iostream>
using namespace std;
int main()
{
	char a[7]={'s','h','u','b','h','a','m'} ,i,j,c;
	cout<<"Elements In normal Order is: \n";
	for(i=0; i<7; i++){
        cout<<a[i]<<"\t";	
    
	}
	cout<<endl;
	for(i=0; i<7; i++){
		for(j=i+1; j<7; j++){
			if(a[i]>a[j]){
				c=a[i];
				a[i]=a[j];
				a[j]=c;
				
			}
			
		}
	
    
	}
	cout<<"Elements In Lexicographical Order is: \n";
	for(i=0; i<7; i++){
        cout<<a[i]<<"\t";	
    
	}
}