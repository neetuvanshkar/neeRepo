//17. C++ program to find the factor of any number  
#include<iostream>
using namespace std;
int main()
{
	int a,c=1;
	cout<<"Enter the number:- ";
	cin>>a;
	cout<<"The factor of "<<a<<" is:- ";
	for(int i=1; i<=a; i++){
	if(a%i==0){
		cout<<i<<" ";
	}   
	
	}

	
}