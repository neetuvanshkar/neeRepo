//14. C++ Program To Find The HCF Or LCM Of A Given Number 
#include<iostream>
using namespace std;
int main()
{
	int a,b,HCF,LCM;
	cout<<"Enter the number:- ";
	cin>>a;
	cout<<"Enter the number:- ";
	cin>>b;
	for(int i=1; i<=a && i<=b; i++)
	{
		if(a%i==0 && b%i==0){
			HCF=i;
		}
	  	
		
	}
	cout<<"Higher common factor is:-"<<HCF;
//	LCM=a*b/hcf
    LCM=a*b/HCF;
    cout<<"LCM is:- "<<LCM;
}