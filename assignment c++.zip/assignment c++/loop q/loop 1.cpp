//1. C++Program To Calculate The Factorial Of A Given Number Using Loop 
#include<iostream>
using namespace std;
int main()
{
	int num,t=1;
	cout<<"Enter the number:- ";
	cin>>num;
	for(int i=1; i<=num; i++){
		t=t*i;
	}
	cout<<"the factorial of a number "<<num<<" is "<<t;
	
}