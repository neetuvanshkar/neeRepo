//11. C++ Program To Read Integer (N) And Print First Three Powers (N^1, N^2, 
//N^3) 
#include<iostream>
#include<math.h>
using namespace std;

int main()
{
	int n,c,d,e;
	cout<<"Enter the number:- ";
	cin>>n;
	c=pow(n,1);
	d=pow(n,2);
	e=pow(n,3);
	cout<<"First value:-"<<c<<endl;
	cout<<"second value:-"<<d<<endl;
	cout<<"third value:-"<<e<<endl;
	
}