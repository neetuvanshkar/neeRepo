//16. C++ Program to check the given number is perfect number or not. 
#include<iostream>
using namespace std;
int main()
{
	int a,sum=0,c;
	cout<<"Enter the number:- ";
	cin>>a;
	c=a;
	
	for(int i=1; i<a; i++){
	   if(a%i==0){
	    sum+=i; 
	   }
	}

	
		
if(c==sum){
	cout<<a<<" is a perfect number"<<endl;
		
}
else{
	 cout<<a<<" is not a perfect number"<<endl;
		
	}
	
}