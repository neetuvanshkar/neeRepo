//10. C++ Program For Denomination Of An Amount Using While Loop 
#include<iostream>
using namespace std;
int main()
{
	int a,n2000,n500,n200,n100,n50,n20,n10,n5,n2,n1;
	cout<<"Enter the amount:- ";
	cin>>a;
	while(a!=0){
		n2000=a/2000;
		a=a%2000;
		n500=a/500;
		a=a%500;
		n200=a/200;
		a=a%200;
		n100=a/100;
		a=a%100;
		n50=a/50;
		a=a%50;
		n20=a/20;
		a=a%20;
		n10=a/10;
		a=a%10;
		n5=a/5;
		a=a%5;
		n2=a/2;
		a=a%10;
		n1=a/1;
		a=a%1;
		
		
	}
	cout<<"2000 note is: "<<n2000<<endl;
	cout<<"500 note is: "<<n500<<endl;
	cout<<"200 note is: "<<n200<<endl;
	cout<<"100 note is: "<<n100<<endl;
	cout<<"50 note is: "<<n50<<endl;
	cout<<"20 note is: "<<n20<<endl;
    cout<<"10 note is: "<<n10<<endl;
	cout<<"5 note is: "<<n5<<endl;
    cout<<"2 note is: "<<n2<<endl;
    cout<<"1 note is: "<<n1<<endl;
	
}