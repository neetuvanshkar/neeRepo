//2. C++ Program To Print Table Of Any Number Using For Loop  
#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"Enter the number:- ";
	cin>>num;

	
	for(int i=1; i<=10; i++){
		cout<<num<<"*"<<i<<"="<<num*i<<endl;
		
	}
	
	
	
}