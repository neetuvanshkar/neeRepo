//13. C++ Program To Check Number Is Armstrong Or Not.

#include<iostream>
using namespace std;    // 371 =3*3*3+7*7*7+1*1*1
int main()
{
	int a,i,temp,rem,sum=0;
	cout<<"Enter the number ";
	cin>>a;
	temp=a;
	while(a>0){
		rem=a%10; //1,7
		sum=sum+rem*rem*rem; //1+343+27
		a=a/10;
		
		
	}
	if(temp==sum){
		cout<<temp<<"  Number Is Armstrong";
	}
	else{
		cout<<temp<<"  Number is not Armstrong";
	}
 } 