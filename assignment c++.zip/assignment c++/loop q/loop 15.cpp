//15. C++ Program To Count Letters, Space, Digits, And Others Using If/Else 
//Statements 
#include<iostream>
using namespace std;
int main()
{
	char str[100];
	int v=0,c=0,d=0,s=0,special_char=0;
	cout<<"Enter the string:- ";
	gets(str);
	for(int i=0; str[i]!='\0'; i++){
		if(str[i]=='a' || str[i]=='e' 
		|| str[i]=='i' || str[i]=='o' || str[i]=='u' || str[i]=='A'
		|| str[i]=='E' || str[i]=='I' || str[i]=='O' || str[i]=='U'){
			v++;
		}
    
    else if((str[i]>='a' && str[i]<='z') || 
	str[i]>='A' && str[i]<='Z' ){
		c++;
	}
	else if(str[i]>='0' && str[i]<='9')
    {
		d++;
	}
	else if(str[i]==' ')
    {
		s++;
	}
	else{
		special_char++;
	}
}

	cout<<"vowel is:- "<<v<<endl;
	cout<<"consonent is:- "<<c<<endl;
	cout<<"digit is:- "<<d<<endl;
	cout<<"white space is:- "<<s<<endl;
	cout<<"special_char is:- "<<special_char<<endl;
	
	
}