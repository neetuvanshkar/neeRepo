//3. C++ Program To Print A Reverse Order Of Any Number Using Loop 
#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"Enter the value:- ";
	cin>>a;
	for(int i=a; i>=1; i--){
		cout<<i<<endl;		
	}
	
}