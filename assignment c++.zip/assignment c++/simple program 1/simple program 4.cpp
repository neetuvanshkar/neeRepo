//C++ Program To Convert A Person's Name Into Abbreviated. 
#include<iostream>
using namespace std; 
int main()
{
	char a[20],b[20],c[20];
	cout<<"Enter first,middle,last name:- ";
	cin>>a>>b>>c;
	cout<<"The abbreviated of your name is: "<<a[0]<<"."<<b[0]<<" "<<c;
}