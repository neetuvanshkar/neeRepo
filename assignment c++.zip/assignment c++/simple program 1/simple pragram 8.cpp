//C++ Program To Swap Two Numbers Without Using Third Variable 
#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"Enter first number: ";
	cin>>a;
	cout<<"Enter second number: ";
	cin>>b;
	a=a+b;   //a=10 b=20
	b=a-b;
	a=a-b;
	
	cout<<"your first number is after swapping: "<<a<<endl;
	cout<<"your second number is after swapping: "<<b<<endl;
	
}