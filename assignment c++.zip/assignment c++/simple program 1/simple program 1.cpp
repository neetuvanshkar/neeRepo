//C++ Program To Find Area And Circumference Of Circle. 
#include<iostream>
using namespace std;
int main()
{
	int r;
	cout<<"Enter the radius of a circle:- ";
	cin>>r;
	float Area=3.14*r*r;
	float circumference=2*3.14*r;
	cout<<"Area of the circle is: "<<Area<<endl;
	cout<<"Circumference of circle is: "<<circumference<<endl;
}