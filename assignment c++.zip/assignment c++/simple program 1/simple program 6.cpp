//C++ Program For Converting Temperature Celsius Into Fahrenheit 

#include<iostream>
using namespace std;
int main()
{
	int c;
	cout<<"Enter the temperature celsius:- ";
	cin>>c;
	float F=(c*9/5)+32;
	cout<<"Value converting temperature into fahrenheit is: "<<F;
}