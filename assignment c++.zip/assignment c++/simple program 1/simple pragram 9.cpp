//C++ Program To Print The Sum Of Three Digits Number.
#include<iostream>
using namespace std;
int main()
{
	int n,m,sum=0;
	cout<<"Enter three digit number: ";
	cin>>n;

while(n>0){
	m=n%10;
	sum+=m;
	n=n/10;
	
			
	
}
cout<<"sum of the digit number is: "<<sum;
   
		
	
	
	
}