//5. C++ Program For Calculate A Simple Interest. 
#include<iostream>
using namespace std;
int main()
{
	float a,b,c;
	cout<<"Enter the principal amount:- ";
	cin>>a;
	cout<<"Enter the rate %:- ";
	cin>>b;
	cout<<"Enter the time period:- ";
	cin>>c;
	float S_I=(a*b*c)/100;
	cout<<"The simple intrest is: "<<S_I;
	
	

	
}