//10. C++ Program To Find The Largest Number Between Two Using Ternary 
//Operator. 
#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"Enter the first number: ";
	cin>>a;
	cout<<"Enter the second number: ";
	cin>>b;
    (a>b)?cout<<a<<" "<<"is greater":cout<<b<<" "<<"is greater";
	
	
}