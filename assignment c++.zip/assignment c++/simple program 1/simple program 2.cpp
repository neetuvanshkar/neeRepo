//2. C++ Program To Print ASCII Value Of Character. 
#include<iostream>
using namespace std;
int main()
{
	char a;
	cout<<"Enter the character:- ";
	cin>>a;

	int ascii_val=(int)a;
	
	cout<<"The ascii value of the character is: "<<a<<": "<<ascii_val;







//print all ascci value between 0 to 127	
//	for(char i=0; i<=126; i++){
//		cout<<"Thte ascii value of character: "<<i<<": "<<(int)i<<endl;
//		
//	}

	
}