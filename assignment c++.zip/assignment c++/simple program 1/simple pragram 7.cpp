//C++ Program To Display Size Of Different Datatype. 
#include<iostream>
using namespace std;
int main()
{
   int a;
   float b;
   string c;
   char d;
   double e;
   long double f;
   long long g;
   cout<<"The size of integer value is: "<<sizeof(a)<<" "<<"byte"<<endl;
   cout<<"The size of float value is: "<<sizeof(b)<<" "<<"byte"<<endl;
   cout<<"The size of string value is: "<<sizeof(c)<<" "<<"byte"<<endl;
   cout<<"The size of char value is: "<<sizeof(d)<<" "<<"byte"<<endl;
   cout<<"The size of double value is: "<<sizeof(e)<<" "<<"byte"<<endl;
   cout<<"The size of long double value is: "<<sizeof(f)<<" "<<"byte"<<endl;
   cout<<"The size of long long value is: "<<sizeof(g)<<" "<<"byte"<<endl;

   	
}