//interview q 
#include<iostream>
using namespace std;
int main()
{
	int arr[]={0,1,1,2,0,2};
	int i,j,c;
	cout<<"The previous array is: ";
	for(i=0; i<6; i++){
		cout<<arr[i]<<"  ";
	}
	cout<<endl;
	for(i=0; i<6; i++){
		for(j=i+1; j<6; j++){
			if(arr[i]>arr[j]){
				c=arr[i];
				arr[i]=arr[j];
				arr[j]=c;
			}
		}
	}
	cout<<"The array is: ";
	for(i=0; i<6; i++){
		cout<<arr[i]<<"  ";
	}
}