#include<iostream>
using namespace std;
int main()
{
	int a[5],i;
	for(i=1; i<=5; i++){
		cout<<"Enter the value "<<i<<" :";
		cin>>a[i];
	}
	cout<<"Even number:";

	for(i=1; i<=5; i++){
		if(a[i]%2==0){
			cout<<a[i]<<"\t";
			
		}
		
	}
	cout<<endl;
	cout<<"odd number:";

	for(i=1; i<=5; i++){
		if(a[i]%2==1){
			cout<<a[i]<<"\t";
			
		}
		
		
	}


	
}
