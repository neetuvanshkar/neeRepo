//assending order
#include<iostream>
using namespace std;
int main()
{
	int a,i,b[5],c,j;
	cout<<"Enter the number of array element: ";
	cin>>a;
	for(i=0; i<a; i++){
		cout<<"Enter the value "<<i+1<<" :";
		cin>>b[i];
	}
	for(i=0; i<a; i++){    // 1,3,4,2,5
		for(j=i+1; j<a; j++){
			if(b[i]>b[j]){
				c=b[i];
				b[i]=b[j];
				b[j]=c;
			}
		}
	}
	cout<<"The ascending order of: ";
	for(i=0; i<a; i++){
		cout<<b[i]<<"\t";
	}
	

	
}