//sum of number
#include<iostream>
using namespace std;
int main()
{
	int arr[5],i;
	int sum=0;
	for(i=1; i<=5; i++){
		cout<<"Enter the value"<<" "<<i<<": ";
		cin>>arr[i];
	}
	
	for(i=1; i<=5; i++){
		sum=sum+arr[i];
	}
	cout<<"sum of all number is: "<<sum;
	
	
}
