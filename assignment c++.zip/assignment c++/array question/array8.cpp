//prime number 
#include<iostream>
using namespace std;
int main()
{
	int a[5],c=0,i;
	for(i=1; i<=5; i++){
	  cout<<"Enter the number: ";
	  cin>>a[i];
		
	}
	for(i=1; i<=5; i++){
		if(a[i]%i==0){
//			c+=1;
cout<<a[i];
		}
	}
//	if(c==2){
//		cout<<a<<" "<<"prime number"<<endl;
//	}
//	else{
//		cout<<a<<" "<<"not prime number"<<endl;
//	}
	
}