#include<iostream>
using namespace std;
int main()
{
	int arr[10],i;
	cout<<"Enter 10 values: \n";
	for(i=1; i<=10; i++){
		cin>>arr[i];
	}
	cout<<"value store in: "; 
	for(i=1; i<=10; i++)
	{
		cout<<arr[i]<<"\t";
	}
}