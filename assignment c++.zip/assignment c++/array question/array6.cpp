//decending order
#include<iostream>
using namespace std; 
int main()
{
	int i,j,a,b[20],c;
	cout<<"Enter the number of array element :";
	cin>>a;
	for(i=0; i<a; i++){
		cout<<"Enter the value "<<i+1<<" :";
		cin>>b[i];
	}
	cout<<"without decending order: ";
	for(i=0; i<a; i++){
		cout<<b[i]<<"\t";
	
	}
	cout<<endl;
	cout<<endl;
	cout<<endl;
	
	for(i=0; i<a; i++){
		for(j=i+1; j<a; j++){
			if(b[i]<b[j]){
				c=b[i];
				b[i]=b[j];
				b[j]=c;
				
			}
		}
	}
	cout<<"The value in decending order is:";
	for(i=0; i<a; i++){
		cout<<b[i]<<"\t";
	}
}