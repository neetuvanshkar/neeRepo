//reverse array
#include<iostream>
using namespace std;
int main()
{
	int arr[5],i;
	for(i=1; i<=5; i++){
		cout<<"Enter value"<<" "<<i<<":"<<" "<<endl;
	    cin>>arr[i];
		
	}
	cout<<"the array is: \n"<<endl;
	for(i=1; i<=5; i++){
		cout<<arr[i]<<"\t";
		
	}
	cout<<endl;
	cout<<endl;
	
	cout<<"Reverse of array is: \n";
	for(i=5; i>=1; i--){
		cout<<arr[i]<<"\t";
	}

   
}