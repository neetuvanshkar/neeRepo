//4. C++ Program to Count Positive and Negative Numbers Using While Loop 
#include<iostream>
using namespace std;
int main()
{ 
    int a,i;
    cout<<"Enter the array length:- ";
    cin>>a;
	int arr[a];
	for(i=0; i<a; i++){
		cout<<"Enter the number "<<i+1<<":- ";
		cin>>arr[i];	
	}
	cout<<"The positive value are:-  5";
	for(i=0; i<a; i++){
		if(arr[i]>0){
			cout<<arr[i]<<"\t";
		}
	
	}
	cout<<endl;
	cout<<endl;
    cout<<"The negative value are:-  ";
	for(i=0; i<a; i++){
		if(arr[i]<0){
			cout<<arr[i]<<"\t";
		}
	
	}
	
   
	
}