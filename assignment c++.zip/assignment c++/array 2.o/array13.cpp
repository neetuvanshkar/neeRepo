//13. C++ program to merge two arrays
#include<iostream>
using namespace std;
int main()
{
	int i,j;
	int arr1[10],arr2[10],marged[20];
	cout<<"Now enter the array 1 values \n";
	for(i=0; i<10; i++){
		cout<<"Enter the number "<<i+1<<":- ";
		cin>>arr1[i];
		marged[i]=arr1[i];
	}
	cout<<"Now enter the array 2 values \n";
	for(j=0; j<10; j++){
		cout<<"Enter the number "<<j+1<<":- ";
		cin>>arr2[j];
		marged[i]=arr2[j];
		i++;
	}
	cout<<endl;
	cout<<"The array 1 values are:- ";
	for(int i=0; i<10; i++){
		cout<<arr1[i]<<" ";
	}
	cout<<endl;
	cout<<"The array 2 values are:- ";
	for(int j=0; j<10; j++){
		cout<<arr2[j]<<" ";
		
	}
	cout<<endl;
		cout<<endl;
	cout<<"so the marge array are:- ";
	for(int j=0; j<20; j++){
		cout<<marged[j]<<" ";
		
	}
	
}