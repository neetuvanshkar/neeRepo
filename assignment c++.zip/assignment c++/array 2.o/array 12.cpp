//12. C++ program to count frequency elements from an array 
#include<iostream>
using namespace std;
int main()
{
	int a,i,j;
	cout<<"Enter the array limit:- ";
	cin>>a;
	int arr[a];
	for(i=0; i<a; i++){
		cout<<"Enter the number "<<i+1<<":- ";
		cin>>arr[i];
	}
	for(i=0; i<a; i++){
		int x=arr[i];
		int count=0;
		
	if(x==-1) continue;	
		for(j=0; j<a; j++){
			if(arr[j]==x){
				count++;
				arr[j]=-1;
			}
		
	}
	cout<<"frequency of "<<x<<" is "<<count<<endl;

}
}