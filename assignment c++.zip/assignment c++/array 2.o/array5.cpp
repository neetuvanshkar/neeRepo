//5. C++ Program To print   Prime number from An Array 
#include<iostream>
using namespace std;
int main()
{
	int a[5],i,c,j,n,f;
	cout<<"Enter 5 elements:- \n";
	for(i=0; i<5; i++){
		cin>>a[i];
		
	}
	for(i=0;i<5; i++){
		n=a[i];  //11
		f=0;
		for(j=2; j<n; j++){
			if(n%j==0){
				f=1;
				break;
			}
		}
		if(f==0){
			cout<<n<<" is prime"<<endl;
		}
		else{
			cout<<n<<" is not prime"<<endl;
		}
	
	}

	
	
}