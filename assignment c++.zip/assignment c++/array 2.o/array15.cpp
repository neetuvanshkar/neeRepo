//15. C++ program to find sub array. 
#include<iostream>
using namespace std;
int main()
{
	int a[4]  ={0,1,2,3},i,j,k;
	cout<<"The sub array are:- \n";
	for(i=0; i<4; i++)
	{
		for(j=0; j<4-i; j++)
		{
			for(k=i; k<=i+j; k++){
				cout<<a[k]<<" ";
				
			}
           
			cout<<endl;
		}
		cout<<endl;
	}
}