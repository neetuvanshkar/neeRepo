//14. C++ program to display array in transpose manner 
#include<iostream>
using namespace std;
int main()
{
	int a[3][3],i,j,b[3][3];
	cout<<"Enter the element:- \n";
	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
//			cout<<"\t";
			cin>>a[i][j];
		
			
			
		}
		cout<<endl;
		
	}
	cout<<"The metrix is: \n";
	cout<<endl;
	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			cout<<a[i][j]<<" ";
			
		}
		cout<<endl;
	}
	cout<<"the transpose of the matrix is: \n";
		cout<<endl;
	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			b[i][j]=a[j][i];
			cout<<b[i][j]<<" ";
			
		}
		cout<<endl;
	}
}