//18. C++ program to display array in following manner 
//Input:[1,2,0,2,0,1] 
//Output:[0,0,1,1,2,2] 
 
#include<iostream>
using namespace std;
int main()
{
	int a,i,j,c;
	int arr[6]={1,2,0,2,0,1};
	
    cout<<endl;
    cout<<"input"<<"[";
	for(i=0; i<6; i++){
	  	cout<<arr[i]<<",";
	}
	cout<<"]";
	cout<<endl;
	for(i=0; i<6; i++){
		for(j=0; j<6; j++){
			if(arr[i]<arr[j])
			{
				c=arr[i];
				arr[i]=arr[j];
				arr[j]=c;
				
			}
           
		}
	
	}
	cout<<endl;
	cout<<endl;
	cout<<endl;
	cout<<"output:- "<<"[";
	for(i=0; i<6; i++){
		cout<<arr[i]<<",";
	}
	cout<<"]";
	
	
} 