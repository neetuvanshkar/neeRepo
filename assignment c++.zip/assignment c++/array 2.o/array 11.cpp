//11. C++ program to unique values from an array 
#include<iostream>
using namespace std;
int main()
{
	int a,i,j;
	cout<<"Enter the limit of an array:- ";
	cin>>a;
	int arr[a];
	for(i=0; i<a; i++){
		cout<<"Enter the number "<<i+1<<":- ";
		cin>>arr[i];
	}
	cout<<"The unique value are:- ";
	for(i=0; i<a; i++){        //24,25,26,27,26
		for(j=0; j<a; j++){    //
			if(arr[i]==arr[j]){
				break;
			}
//             cout<<arr[j]<<endl;
			
		}
		if(i==j){
			cout<<arr[i]<<" ";
		}
	}
	
	
}