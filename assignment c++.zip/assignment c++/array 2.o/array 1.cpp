//1. C++ Program To Print All Value Of An Array 
#include<iostream>
using namespace std;
int main()
{
	int a[5];
	cout<<"Enter the 5 element:- \n";

	for(int i=1; i<=5; i++){ 
	   	cin>>a[i];	
	
	}
	cout<<"All the value:- \n"<<endl;
	for(int i=1; i<=5; i++){ 
	   	cout<<a[i]<<endl;	
	
	}
	
}