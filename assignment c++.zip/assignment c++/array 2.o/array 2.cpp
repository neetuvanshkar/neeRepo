//2. C++ Program To Print Reverse Order And Print Sum Of Its Element Of An 
//Array 
#include<iostream>
using namespace std;
int main()
{
	int a[5],i;
	cout<<"Enter the 5 element:- \n";

	for(i=1; i<=5; i++){ 
	   	cin>>a[i];	
	
	}
	cout<<"All the value are:- \n"<<endl;
	for(i=1; i<=5; i++){ 
	     cout<<a[i]<<" , ";	
	
	}
	cout<<endl;
	cout<<"All the value in reverse order:- \n"<<endl;
	for(i=5; i>=1; i--){ 
	   	cout<<a[i]<<" , ";	
	
	}
	
}