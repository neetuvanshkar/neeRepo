//3. C++ Program To print sum of Even  and Odd values from  An Array
#include<iostream>
using namespace std;
int main()
{
	int arr[5]={25,56,89,78,14};
	int sum1=0,sum2=0;
	
	cout<<"Even number is:- ";
	for(int i=0; i<5; i++){
		if(arr[i]%2==0){
			cout<<arr[i]<<"\t";
			sum1+=arr[i];
			
			
			
		}
		
	
	}
	cout<<endl;
	cout<<"sum of the even number is:-"<<sum1<<endl;
	cout<<endl;
	cout<<endl;
	cout<<"odd number is:- ";
	for(int i=0; i<5; i++){
		if(arr[i]%2!=0){
			cout<<arr[i]<<"\t";
			sum2+=arr[i];
			
			
		}	
	
	}
	cout<<endl;
	cout<<"sum of odd number is:- "<<sum2<<endl;
 } 