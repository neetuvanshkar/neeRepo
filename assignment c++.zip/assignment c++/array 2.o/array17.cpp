//17. C++ program to display array in descending order 
#include<iostream>
using namespace std;
int main()
{
	int a,i,j,c;
	cout<<"Enter the limit of an array:- ";
	cin>>a;
	int arr[a];
	for(i=0; i<a; i++){
		cout<<"Enter the number "<<i+1<<":- ";
		cin>>arr[i];
	}
	cout<<endl;
	cout<<"normal array:- ";
	for(i=0; i<a; i++){
		cout<<arr[i]<<"\t";
	}
	cout<<endl;
	for(i=0; i<a; i++){
		for(j=i+1; j<a; j++){
			if(arr[i]>arr[j])
			{
				c=arr[i];
				arr[i]=arr[j];
				arr[j]=c;
				
			}
           
		}
	
	}
	cout<<"descending of an array is:- ";
	for(i=0; i<a; i++){
		cout<<arr[i]<<"\t";
	}
	
	
} 