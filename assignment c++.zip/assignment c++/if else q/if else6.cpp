//6. C++ Program to Check Vowel or Consonant Using if Else 
#include<iostream>
using namespace std;
int main(){
	int i1=1;
while(i1<=7){

	char a;
	cout<<"Enter the character:- ";
	cin>>a;
	if(a=='a' || a=='e' || a=='i' || a=='o' || a=='u'){
		cout<<a<<" "<<"is a vowel"<<endl;
	}
	else if(a=='A' || a=='E' || a=='I' || a=='O' || a=='U'){
			cout<<a<<" "<<"is a vowel"<<endl;
	}
	else{
		cout<<a<<" "<<"is a consonant"<<endl;
	}
  i1++;

}
	
	
}