//12. C++ Program To Calculate Electricity Bill According To Given Slabs 
//Slabs:1-100 @ 5/unit 
//101-500 @7/unit 
//501-1000 @9/unit 
//Above 1000 @ 12/unit 
#include<iostream>
using namespace std;
int main()
{
	int i=0;
while(i<7){

	int a;
	cout<<"Enter the electricity unit value:- ";
	cin>>a;
	if(a>=1 && a<=100){
		cout<<"5 rs unit"<<endl;
	}
	else if(a>100 && a<=500){
		cout<<"7 rs unit"<<endl;
	}
	else if(a>500 && a<=1000){
		cout<<"10 rs unit"<<endl;
	}
	else{
		cout<<"12 rs unit"<<endl;
	}
i++;	
}
	
}