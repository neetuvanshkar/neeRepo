//13. C++Program To Check Date Validation (Valid Or Not) Using If/Else Statements 
#include<iostream>
using namespace std;
int main()
{
	int d,d1,c,a;
	d=30/02/2010;
	d1=20/10/2010;
//	 c=30/02/2010;
	a=20/10/2010;
	if(c==d1){
		cout<<"not valid date"<<endl;	
	}
	else{
		cout<<"valid date"<<endl;
		
	}
}


