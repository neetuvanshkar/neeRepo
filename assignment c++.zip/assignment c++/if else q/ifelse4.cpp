//C++ Program To Check Whether a Character Is Uppercase, Lowercase Alphabet 
//A Digit Or A Special Symbol  
#include <iostream>
using namespace std;
int main()
{
    char a;
    cout << "Enter the character:- ";
    cin>>a;
    if(a>='a' && a<='z'){
    	cout<<a<<" is a lowercase"<<endl;
	}
	else if(a>='A' &&  a<='Z'){
		cout<<a<<" is a uppercase"<<endl;
		
		
	}
	else if(a>='0' && a<='9'){
		cout<<a<<" is a digit"<<endl;
		
	}
	else{
		cout<<a<<" is special character";
	}
	
   
}