#include<iostream>
using namespace std; 
int main()
{
	float a,b,c,d,e,f;
	cout<<"Enter the number of 5 subject marks:- ";
	cin>>a>>b>>c>>d>>e;
	f=a+b+c+d+e;
	if(f>0){
		cout<<"Total is:- "<<f<<endl;
		cout<<"Percentage of all 5 subject marks is:- "<<(f/500)*100;
	}
	else{
		cout<<"Negative marks";
	}
}