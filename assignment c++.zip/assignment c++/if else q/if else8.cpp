//C++ Program To Find Quotient And Reminder Of Two Numbers Using If/Else 
//Statements

//6. C++ Program to Check Vowel or Consonant Using if Else 
#include<iostream>
using namespace std;
int main(){



	int a,b,c,d;
	cout<<"Enter the value 1:- ";
	cin>>a;
	cout<<"Enter the value 2:- ";
	cin>>b;
	c=a%b;
	d=a/b;
	if(c){
		cout<<c<<" is remainder value"<<endl;
	}
	else if(d){
		cout<<d<<" is quotient value"<<endl;
	}
	

	
	
}