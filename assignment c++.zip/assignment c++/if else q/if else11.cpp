//11. C++Program To Check Age Between 40 To 60 Using If/Else Statements 
#include<iostream>
using namespace std;
int main()
{
	int age;
	cout<<"Enter your age:- ";
	cin>>age;
	if(age>=40 && age<=60){
		cout<<"Your age between 40 and 60"<<endl;
	}
	else{
	  	cout<<"Your age is not between 40 and 60"<<endl;
	}
	
	
}