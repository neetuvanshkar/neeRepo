//14. C++ Program To Determine Whether The Seller Made Profit or Loss. Also, 
//Determine How Much Profit or Loss He Made. 
#include<iostream>
using namespace std;
int main()
{
	int s_p,c_p,t;
	cout<<"Enter the selling price:- ";
	cin>>s_p;
	cout<<"Enter the cost price:- ";
	cin>>c_p;

	if(s_p>c_p){
		cout<<"you made profit is "<<s_p-c_p<<endl;
		
	}
	else if(c_p>s_p){
		cout<<"you made lost is "<<c_p-s_p<<endl;
	}
	else{
		cout<<"you have no profit and no lose "<<s_p<<"="<<c_p<<endl;
	}
	
}