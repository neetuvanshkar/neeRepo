//15. C++ Program To Generate Grade System of Mark sheet According To 3 Subjects 
//Using following criteria: 
//Note:  35-44 D*,45-59 C*,60-74  B* ,75-100 A*,Below 35 Not Promoted*  

#include<iostream>
using namespace std;
int main()

{
int	n=0;
while(n<7){

	float mark1,mark2,mark3,t,m;
	cout<<"Enter the subject 1 marks:- ";
	cin>>mark1;
	cout<<"Enter the subject 2 marks:- ";
	cin>>mark2;
	cout<<"Enter the subject 3 marks:- ";
	cin>>mark3;
	m=mark1+mark2+mark3;
	t=((mark1+mark2+mark3)/300)*100;
	cout<<"total is:- "<<m<<endl;
	cout<<"percentage is:- "<<t<<" %"<<endl;
	if(t>=35 && t<=44){
		cout<<"your percentage is:- "<<t<<" and"<<" grade is D"<<endl;
	}
	else if(t>=45 && t<=59){
		cout<<"your percentage is:- "<<t<<" and"<<" grade is C"<<endl;
	}
	else if(t>=60 && t<=74){
		cout<<"your percentage is:- "<<t<<" and"<<" grade is B"<<endl;
	}
	else if(t>=75 && t<=100){
		cout<<"your percentage is:- "<<t<<" and"<<" grade is A"<<endl;
	}
	else{
		cout<<"your percentage is:- "<<t<<" and"<<" below 35 not promoted"<<endl;
		
	}
}
	
}