//. C++ Program To Check Given Number Is Even Or Odd. 
#include <iostream>
using namespace std;
int main()
{
    int a;
    cout << "Enter the number:- ";
    cin>>a;
    if(a%2==0){
    	cout<<a<<" is Even number"<<endl;
	}
	else{
		cout<<a<<" is odd number"<<endl;
	}
   
}