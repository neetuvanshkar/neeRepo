//10. C++ Program To Check Year Is Leap Year Or Not Using If/Else Statements 
#include<iostream>
using namespace std;
int main(){
	int a;
	cout<<"Enter the year:- ";
	cin>>a;
	if(a%400==0){
		cout<<a<<" is a leap year"<<endl;
		
	}
	else if(a%4==0 && a%100!=0){
		cout<<a<<" is a leap year"<<endl;
		
	}
	else{
		cout<<a<<" not a leap year"<<endl;
	}





	

	
	
}