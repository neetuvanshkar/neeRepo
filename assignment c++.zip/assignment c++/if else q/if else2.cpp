//2. C++ Program To Check Number Is Positive Or Negative 
#include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"Enter the number to check is positive or negative:- ";
	cin>>a;
	if(a==0){
		cout<<a<<" is a neutral number"<<endl;
	}
	else if(a>0){
		cout<<a<<" is positive number"<<endl;
		
	}
	else{
		cout<<a<<" is negative number"<<endl;
	}
	
	
}