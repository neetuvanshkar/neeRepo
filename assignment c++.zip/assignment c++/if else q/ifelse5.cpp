//5. C++ Program To Find Greatest Among Three Numbers  
#include<iostream>
using namespace std;
int main(){
	int i=1;
while(i<=7){

	int a,b,c;
	cout<<"Enter first number:- ";
	cin>>a;
	cout<<"Enter second number:- ";
	cin>>b;
	cout<<"Enter third number:- ";
	cin>>c;
	if(a>b && a>c){
		cout<<a<<" "<<"Your first value is greater"<<endl;
	}
	else if(b>a && b>c){
		cout<<b<<" "<<"Your second value is greater"<<endl;	
	}
	else if(c>a && c>b){
		cout<<c<<" "<<"Your third value is greater"<<endl;	
	}
	else if(a=b=c){
		cout<<a<<","<<b<<","<<c<<" "<<"All value is equal."<<endl;
	}

else{
	cout<<"invalid value"<<endl;
}
i++;
}
	
	
}